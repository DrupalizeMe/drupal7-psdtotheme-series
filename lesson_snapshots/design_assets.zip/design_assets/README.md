Design Assets
======================

Files extracted from the PSD file for use in the Domicile theme.
