A folder for all CSS files. Don't forget to link these files from the .info file!
