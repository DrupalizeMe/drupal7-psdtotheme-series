A folder for your custom tpl.php files.
