A folder for SASS files.
