A folder for all images.
