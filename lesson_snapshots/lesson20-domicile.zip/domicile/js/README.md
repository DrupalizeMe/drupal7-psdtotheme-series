A folder for all JS files. Don't forget to link them through the .info file!
